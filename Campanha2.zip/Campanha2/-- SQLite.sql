-- SQLite
INSERT INTO roupas (tipo, pontuacao)
VALUES ('Roupa Comum', 1),
('Agasalho', 2),
('Roupa Nova', 5),
('Roupa de Cama Usada', 10),
('Roupa de Cama Nova', 20);